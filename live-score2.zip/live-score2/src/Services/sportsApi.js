// src/Services/sportsApi.js
import axios from 'axios';

const BASE_URL = 'https://www.thesportsdb.com/api/v1/json/1';

// Fetch last events (matches) for a team
export const fetchLiveScores = async (teamId = '133604') => {
  try {
    const res = await axios.get(`${BASE_URL}/eventslast.php?id=${teamId}`);
    if (!res.data || !res.data.results) throw new Error("404: No results found");
    return res.data.results;
  } catch (err) {
    console.error("fetchLiveScores error:", err.message);
    throw err;
  }
};

// Fetch team status
export const fetchTeamStatus = async (teamId = '133604') => {
  try {
    const res = await axios.get(`${BASE_URL}/lookupteam.php?id=${teamId}`);
    if (!res.data || !res.data.teams) throw new Error("404: Team not found");
    return res.data.teams[0];
  } catch (err) {
    console.error("fetchTeamStatus error:", err.message);
    throw err;
  }
};

// Fake player rankings
export const fetchPlayerRankings = async () => {
  return [
    { name: 'Player 1', rank: 1 },
    { name: 'Player 2', rank: 2 },
    { name: 'Player 3', rank: 3 },
  ];
};
