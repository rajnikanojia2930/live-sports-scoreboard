import React, { useEffect, useState } from 'react';
import { fetchPlayerRankings } from '../Services/sportsApi';

const PlayerRankings = () => {
  const [players, setPlayers] = useState([]);

  useEffect(() => {
    const getData = async () => {
      const data = await fetchPlayerRankings();
      setPlayers(data);
    };

    getData();
  }, []);

  return (
    <div>
      <h2>Player Rankings</h2>
      <ol>
        {players.map((player, i) => (
          <li key={i}>{player.name} - Rank {player.rank}</li>
        ))}
      </ol>
    </div>
  );
};

export default PlayerRankings;
