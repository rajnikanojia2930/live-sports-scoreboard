import React, { useEffect, useState } from 'react';
import { fetchTeamStatus } from '../Services/sportsApi';

const TeamStatus = ({ teamId }) => {
  const [team, setTeam] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const getStatus = async () => {
      try {
        const data = await fetchTeamStatus(teamId);
        setTeam(data);
        setError('');
      } catch (err) {
        setError('⚠️ Team not found (404 or network error).');
      }
    };

    getStatus();
  }, [teamId]);

  return (
    <div>
      <h2>Team Status</h2>
      {error ? <p style={{ color: 'red' }}>{error}</p> : (
        team && (
          <div>
            <p><strong>Team:</strong> {team.strTeam}</p>
            <p><strong>Stadium:</strong> {team.strStadium}</p>
            <p><strong>Location:</strong> {team.strStadiumLocation}</p>
          </div>
        )
      )}
    </div>
  );
};

export default TeamStatus;
