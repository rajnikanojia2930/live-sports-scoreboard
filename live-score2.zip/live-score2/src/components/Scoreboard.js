import React, { useEffect, useState } from 'react';
import { fetchLiveScores } from '../Services/sportsApi';

const Scoreboard = () => {
  const [scores, setScores] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const getData = async () => {
      try {
        const result = await fetchLiveScores();
        setScores(result);
        setError('');
      } catch (err) {
        setError('⚠️ Unable to fetch live scores (404 or network error).');
      }
    };

    getData();
    const interval = setInterval(getData, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div>
      <h2>Live Scores</h2>
      {error ? <p style={{ color: 'red' }}>{error}</p> : (
        <ul>
          {scores.map((match, idx) => (
            <li key={idx}>
              {match.strEvent}: {match.intHomeScore} - {match.intAwayScore}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Scoreboard;
