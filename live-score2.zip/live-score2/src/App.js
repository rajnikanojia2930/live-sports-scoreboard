import React from 'react';
import Scoreboard from './components/Scoreboard';
import TeamStatus from './components/TeamStatus';
import PlayerRankings from './components/PlayerRankings';
import ErrorBoundary from './components/ErrorBoundary';

function App() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>🏆 Live Sports Scoreboard</h1>
      <ErrorBoundary>
        <Scoreboard />
        <TeamStatus teamId="133604" />
        <PlayerRankings />
      </ErrorBoundary>
    </div>
  );
}

export default App;
